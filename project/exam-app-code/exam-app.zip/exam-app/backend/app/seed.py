from sqlalchemy.orm import Session

from app.config import settings
from app.models import Exam, Option, Question, Role, User
from app.security import hash_password

DEMO_INSTRUCTIONS = """1. This paper has 5 questions. Each one appears on its own screen.
2. You get 2 minutes per question. The clock starts the moment the question loads.
3. Once you move on, you cannot come back. Answers are final.
4. A correct answer scores +4. A wrong answer scores -1. Leaving it blank scores 0.
5. If the timer reaches zero, the question is recorded as unattempted.
6. The clock runs on the server. Refreshing the page will not reset it.
7. Keep this tab open. Closing it does not pause the timer."""

DEMO_QUESTIONS = [
    ("Which data structure uses First-In-First-Out ordering?",
     [("Queue", True), ("Stack", False), ("Binary tree", False), ("Hash map", False)]),
    ("What is the time complexity of binary search on a sorted array of n elements?",
     [("O(log n)", True), ("O(n)", False), ("O(n log n)", False), ("O(1)", False)]),
    ("In relational databases, which key uniquely identifies each row in a table?",
     [("Primary key", True), ("Foreign key", False), ("Candidate index", False), ("Composite view", False)]),
    ("Which HTTP status code means the request succeeded and a resource was created?",
     [("201", True), ("200", False), ("204", False), ("301", False)]),
    ("Which of these is NOT a property of a database transaction under ACID?",
     [("Availability", True), ("Atomicity", False), ("Isolation", False), ("Durability", False)]),
]


def seed(db: Session) -> None:
    admin = db.query(User).filter(User.email == settings.ADMIN_EMAIL).first()
    if not admin:
        db.add(User(
            full_name="System Administrator",
            email=settings.ADMIN_EMAIL,
            password_hash=hash_password(settings.ADMIN_PASSWORD),
            role=Role.admin,
        ))
        db.commit()
        print(f"[seed] admin account created: {settings.ADMIN_EMAIL}")

    if not settings.SEED_DEMO_EXAM:
        return
    if db.query(Exam).count():
        return

    exam = Exam(
        title="Computer Science Fundamentals",
        description="A short screening paper covering data structures, algorithms, databases and web basics.",
        instructions=DEMO_INSTRUCTIONS,
        seconds_per_question=settings.QUESTION_TIME_SECONDS,
        marks_correct=4,
        marks_wrong=-1,
        marks_unattempted=0,
    )
    db.add(exam)
    db.flush()

    for qi, (text, opts) in enumerate(DEMO_QUESTIONS):
        q = Question(exam_id=exam.id, text=text, order_index=qi)
        db.add(q)
        db.flush()
        # Shuffle deterministically so the correct answer isn't always first.
        ordered = opts[qi % len(opts):] + opts[:qi % len(opts)]
        for oi, (otext, is_correct) in enumerate(ordered):
            db.add(Option(question_id=q.id, text=otext, is_correct=is_correct, order_index=oi))

    db.commit()
    print("[seed] demo exam created")
