Which of the following approach is used by C++?
Left-right
Right-left
Bottom-up  
Top-down

(c) //right